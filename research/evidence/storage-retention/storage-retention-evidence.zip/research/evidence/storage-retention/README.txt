neatroots storage/retention reproduction

Tested commit: 591357e8a650b8a9fcaff7bdb41e1aabe03fe8a5
Environment: macOS 26.5.1 arm64, Node 25.6.1
The application source is unchanged. This archive contains tests and evidence only.

In a neatroots checkout at that commit:
1. Copy research/repros/storage-retention.mts from this archive into the same path.
2. Run pnpm install --frozen-lockfile at the repository root.
3. Run these commands at the repository root:

pnpm --filter @neatlogs/neatroots exec tsx ../../research/repros/storage-retention.mts delete-control
pnpm --filter @neatlogs/neatroots exec tsx ../../research/repros/storage-retention.mts delete
pnpm --filter @neatlogs/neatroots exec tsx ../../research/repros/storage-retention.mts retention-control
pnpm --filter @neatlogs/neatroots exec tsx ../../research/repros/storage-retention.mts retention

The control cases exit 0. The failure cases exit 1 because the assertions catch the bug.
Each case creates and removes a separate temporary home. No real credentials or hosted models are needed.

The delete case sends four updated span outputs through the actual local HTTP collector.
The retention case calls the same Store.sweep method as automatic retention.
The small 802816-byte cap makes the failure quick to reproduce. It is not the default cap.
Raw logs include all three trials. JSON files contain the captured observations.
The screenshots show trial 1. Trials 2 and 3 produced the same observations.
Absolute checkout paths in raw error stacks are replaced with <checkout>.
